# Roleta Congelante
Roleta interativa para lives no OBS.